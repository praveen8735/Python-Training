items = ['alpha', 'beta', 'charlie']

# for item in items:
#    print(item)

print(iter('pam'))

li = iter('pam')
print(next(li))
print(next(li))
print(next(li))
# print(next(li))
