import sys

print('Platform :', sys.platform)
print('Python version :', sys.version)