"""functional programming"""

print(lambda x, n: x ** n)

power = lambda x, n: x ** n
print(power(2, 4))
