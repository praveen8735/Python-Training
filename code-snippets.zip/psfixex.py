def power(x, n=0):
    """positional argument function"""
    return x ** n


print(power(3, 4))
print()
print(power(3))
print()
print(power(n=4, x=5))
