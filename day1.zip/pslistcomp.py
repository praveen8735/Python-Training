# generator

result = [bin(item) for item in range(100000000000000)]
print(result)