def demo():
    """function definition"""
    print('null argument...')


print(demo)


def demo(a, b):
    print(a + b)


demo(11, 22)  # function calling
